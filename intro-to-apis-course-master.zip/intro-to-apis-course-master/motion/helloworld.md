# Hello World

## Python

```python
print('Hello, World!')
```

## JavaScript

```javascript
console.log("Hello, World!");
```

## C#
 
```csharp
Console.WriteLine("Hello, World!");
```

## PHP

```php
echo 'Hello, World!';
```

## Java

```java
System.out.println("Hello, World!");
```

## Ruby

```ruby
puts "Hello, World!"
```
