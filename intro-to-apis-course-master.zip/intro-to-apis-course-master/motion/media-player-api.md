# Fake Media Player API

```javascript
let song = "old-town-road.mp3";
mediaPlayer.play(song);
```
